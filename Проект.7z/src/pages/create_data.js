import React from "react";

const CreateData = () => {
    return (
        <div>
            Add data
        </div>
    );
};

export default CreateData;
